---
name: qq-email-outreach
description: Set up, preview, test, and send controlled small-batch outreach campaigns through QQ Mail SMTP using a local authorization code. Use when the user asks to configure QQ email sending, prepare a contacts CSV, preview personalized outreach emails, send a test email, send today's approved campaign batch, inspect sent logs, or troubleshoot QQ SMTP delivery.
---

# QQ Email Outreach

Use the bundled scripts for deterministic sending. Never request, display, log, or copy a QQ password or QQ authorization code into chat. Keep secrets in the campaign workspace `.env` file only.

## Guardrails

1. Use public business contact details or contacts the user is permitted to email.
2. Require a clear identity, non-deceptive subject, and opt-out sentence in the template.
3. Default to previewing. Do not run a campaign send merely because setup is complete.
4. For a test email, confirm the configured `TEST_RECIPIENT` and send one email only.
5. For a campaign send, preview recipients and count first. Ask for explicit user confirmation immediately before running the send command.
6. Keep `DAILY_LIMIT` at `10` for a new mailbox. Never exceed `50`.
7. If a recipient opts out, remove them from future contact lists before sending another batch.
8. Never copy `.env`, `contacts.csv`, or `sent_log.csv` into the skill directory.

## Workspace Setup

If the current project does not already contain the helper files, initialize them:

```powershell
powershell -ExecutionPolicy Bypass -File "<skill-dir>\scripts\init_workspace.ps1" -TargetDir "<workspace>"
```

Ask the user to open `<workspace>\.env` locally and fill:

```text
QQ_EMAIL=
QQ_AUTH_CODE=
TEST_RECIPIENT=
FROM_NAME=
SUBJECT=
```

Do not ask the user to paste the authorization code into chat.

## Preview

Run:

```powershell
& "C:\Users\user\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" "<workspace>\preview_campaign.py"
```

If that runtime path does not exist, use an available Python executable. Summarize recipient count, addresses, companies, and the first rendered email. Do not send.

## Test Send

After the user confirms the test recipient, run:

```powershell
powershell -ExecutionPolicy Bypass -File "<workspace>\run_test_email.ps1"
```

Report success only when output states that the test email was sent and the user confirms receipt.

## Campaign Send

1. Run preview.
2. Show the user the exact count and recipient list.
3. Ask for explicit confirmation to send that batch.
4. After confirmation, run:

```powershell
powershell -ExecutionPolicy Bypass -File "<workspace>\run_campaign.ps1"
```

5. Summarize successful sends and any error. Do not retry failed sends without checking `sent_log.csv`.

## Troubleshooting

Run:

```powershell
powershell -ExecutionPolicy Bypass -File "<workspace>\check_qq_connection.ps1"
```

Interpret failures in order:

1. DNS failure: local DNS or network problem.
2. HTTPS failure: general internet access problem.
3. QQ SMTP `465` failure: current network, firewall, VPN, or security software blocks SMTP.
4. Authentication failure: SMTP service is disabled or the QQ authorization code is invalid. Ask the user to regenerate an authorization code locally.

Do not weaken firewall settings automatically.
