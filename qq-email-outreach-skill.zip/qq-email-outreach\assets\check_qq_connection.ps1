$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "QQ Mail connection check" -ForegroundColor Cyan
Write-Host "========================"

Write-Host ""
Write-Host "1. Checking DNS..."
try {
    $dns = Resolve-DnsName smtp.qq.com -ErrorAction Stop |
        Where-Object { $_.IPAddress } |
        Select-Object -First 1
    if ($dns) {
        Write-Host "PASS: smtp.qq.com resolves to $($dns.IPAddress)" -ForegroundColor Green
    } else {
        Write-Host "FAIL: DNS returned no usable IP address." -ForegroundColor Red
    }
} catch {
    Write-Host "FAIL: DNS lookup failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "2. Checking HTTPS internet access..."
$https = Test-NetConnection www.baidu.com -Port 443 -WarningAction SilentlyContinue
if ($https.TcpTestSucceeded) {
    Write-Host "PASS: General HTTPS access works." -ForegroundColor Green
} else {
    Write-Host "FAIL: General HTTPS access is blocked." -ForegroundColor Red
}

Write-Host ""
Write-Host "3. Checking QQ Mail SMTP port 465..."
$smtp = Test-NetConnection smtp.qq.com -Port 465 -WarningAction SilentlyContinue
if ($smtp.TcpTestSucceeded) {
    Write-Host "PASS: QQ Mail SMTP port 465 is reachable." -ForegroundColor Green
} else {
    Write-Host "FAIL: QQ Mail SMTP port 465 is blocked." -ForegroundColor Red
    Write-Host "Try a phone hotspot, then check VPN, firewall, or security software."
}
