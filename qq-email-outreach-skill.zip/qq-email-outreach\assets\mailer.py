import csv
import os
import re
import smtplib
import time
from datetime import datetime, timezone
from email.message import EmailMessage
from email.utils import formataddr
from pathlib import Path


OUTLOOK_SMTP_HOST = "smtp-mail.outlook.com"
OUTLOOK_SMTP_PORT = 587
QQ_SMTP_HOST = "smtp.qq.com"
QQ_SMTP_PORT = 465
DEFAULT_CONTACT_FIELDS = ["email", "first_name", "company", "country", "segment", "note"]
SENT_LOG_FIELDS = ["email", "sent_at", "subject"]


class ConfigError(ValueError):
    pass


def read_env(path=".env"):
    env_path = Path(path)
    values = {}
    if not env_path.exists():
        raise ConfigError(f"Missing config file: {env_path}")

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def require_config(config, keys):
    missing = [key for key in keys if not config.get(key)]
    if missing:
        raise ConfigError(f"Missing required config value(s): {', '.join(missing)}")


def render_template(template, contact):
    def replace(match):
        key = match.group(1).strip()
        return str(contact.get(key, "") or "")

    return re.sub(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}", replace, template)


def load_contacts(path="contacts.csv"):
    contacts_path = Path(path)
    if not contacts_path.exists():
        raise FileNotFoundError(f"Missing contacts file: {contacts_path}")

    contacts = []
    with contacts_path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            normalized = {key: (row.get(key, "") or "").strip() for key in DEFAULT_CONTACT_FIELDS}
            email = normalized["email"].lower()
            if not email:
                continue
            normalized["email"] = email
            contacts.append(normalized)
    return contacts


def load_sent_emails(path="sent_log.csv"):
    log_path = Path(path)
    if not log_path.exists():
        return set()

    with log_path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        return {
            (row.get("email", "") or "").strip().lower()
            for row in reader
            if (row.get("email", "") or "").strip()
        }


def select_recipients(contacts, sent_emails, daily_limit):
    selected = []
    for contact in contacts:
        email = contact["email"].lower()
        if email in sent_emails:
            continue
        selected.append(contact)
        if len(selected) >= daily_limit:
            break
    return selected


def build_message(from_email, from_name, to_email, subject, body):
    msg = EmailMessage()
    msg["From"] = formataddr((from_name, from_email))
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.set_content(body)
    return msg


def get_sender_credentials(config):
    if config.get("QQ_EMAIL") and config.get("QQ_AUTH_CODE"):
        return config["QQ_EMAIL"], config["QQ_AUTH_CODE"]
    if config.get("OUTLOOK_EMAIL") and config.get("OUTLOOK_APP_PASSWORD"):
        return config["OUTLOOK_EMAIL"], config["OUTLOOK_APP_PASSWORD"]
    raise ConfigError("Missing sender credentials. Configure QQ_EMAIL and QQ_AUTH_CODE.")


def send_message(config, message):
    username, password = get_sender_credentials(config)
    host = config.get("SMTP_HOST", QQ_SMTP_HOST)
    port = int(config.get("SMTP_PORT", QQ_SMTP_PORT))
    security = config.get("SMTP_SECURITY", "ssl").lower()

    if security == "ssl":
        with smtplib.SMTP_SSL(host, port, timeout=30) as smtp:
            smtp.login(username, password)
            smtp.send_message(message)
        return

    with smtplib.SMTP(host, port, timeout=30) as smtp:
        smtp.starttls()
        smtp.login(username, password)
        smtp.send_message(message)


def append_sent_log(email, subject, path="sent_log.csv"):
    log_path = Path(path)
    exists = log_path.exists()
    with log_path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=SENT_LOG_FIELDS)
        if not exists:
            writer.writeheader()
        writer.writerow(
            {
                "email": email,
                "sent_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "subject": subject,
            }
        )


def sleep_between_messages(seconds):
    if seconds > 0:
        time.sleep(seconds)


def int_config(config, key, default):
    value = config.get(key, "")
    if not value:
        return default
    return int(value)


def load_template(path="email_template.txt"):
    return Path(path).read_text(encoding="utf-8")


def ensure_safe_campaign_limit(limit):
    if limit < 1:
        raise ConfigError("DAILY_LIMIT must be at least 1")
    if limit > 50:
        raise ConfigError("DAILY_LIMIT is capped at 50 for safer Outlook warm-up")
