from mailer import (
    int_config,
    load_contacts,
    load_sent_emails,
    load_template,
    read_env,
    render_template,
    select_recipients,
)


def main():
    config = read_env()
    daily_limit = int_config(config, "DAILY_LIMIT", 10)
    contacts = load_contacts(config.get("CONTACTS_FILE", "contacts.csv"))
    sent_emails = load_sent_emails(config.get("SENT_LOG_FILE", "sent_log.csv"))
    recipients = select_recipients(contacts, sent_emails, daily_limit)
    template = load_template(config.get("TEMPLATE_FILE", "email_template.txt"))

    print(f"Next recipients: {len(recipients)}")
    for contact in recipients:
        print(f"- {contact['email']} | {contact.get('company', '')} | {contact.get('segment', '')}")

    if recipients:
        print("\n--- First email preview ---")
        print(render_template(template, recipients[0]))


if __name__ == "__main__":
    main()
