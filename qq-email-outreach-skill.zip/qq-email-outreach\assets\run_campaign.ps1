$ErrorActionPreference = "Stop"
$python = "C:\Users\user\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"

if (-not (Test-Path $python)) {
    Write-Host "Python runtime not found at:" -ForegroundColor Red
    Write-Host $python
    exit 1
}

Write-Host "Sending the approved campaign batch..." -ForegroundColor Cyan
& $python "send_campaign.py"
