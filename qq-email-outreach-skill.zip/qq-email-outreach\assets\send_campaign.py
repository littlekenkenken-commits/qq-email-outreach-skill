from mailer import (
    append_sent_log,
    build_message,
    ensure_safe_campaign_limit,
    int_config,
    load_contacts,
    load_sent_emails,
    load_template,
    read_env,
    render_template,
    require_config,
    select_recipients,
    send_message,
    sleep_between_messages,
)


def main():
    config = read_env()
    require_config(
        config,
        [
            "QQ_EMAIL",
            "QQ_AUTH_CODE",
            "FROM_NAME",
            "SUBJECT",
        ],
    )

    daily_limit = int_config(config, "DAILY_LIMIT", 10)
    delay_seconds = int_config(config, "DELAY_SECONDS", 90)
    ensure_safe_campaign_limit(daily_limit)

    contacts = load_contacts(config.get("CONTACTS_FILE", "contacts.csv"))
    sent_emails = load_sent_emails(config.get("SENT_LOG_FILE", "sent_log.csv"))
    recipients = select_recipients(contacts, sent_emails, daily_limit)
    template = load_template(config.get("TEMPLATE_FILE", "email_template.txt"))

    if not recipients:
        print("No new recipients to send.")
        return

    print(f"Sending {len(recipients)} email(s).")
    for index, contact in enumerate(recipients, start=1):
        body = render_template(template, contact)
        message = build_message(
            from_email=config["QQ_EMAIL"],
            from_name=config["FROM_NAME"],
            to_email=contact["email"],
            subject=config["SUBJECT"],
            body=body,
        )
        send_message(config, message)
        append_sent_log(contact["email"], config["SUBJECT"], config.get("SENT_LOG_FILE", "sent_log.csv"))
        print(f"{index}/{len(recipients)} sent to {contact['email']}")
        if index < len(recipients):
            sleep_between_messages(delay_seconds)


if __name__ == "__main__":
    main()
