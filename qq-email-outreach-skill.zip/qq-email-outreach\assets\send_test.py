from mailer import (
    build_message,
    load_template,
    read_env,
    render_template,
    require_config,
    send_message,
)


def main():
    config = read_env()
    require_config(
        config,
        [
            "QQ_EMAIL",
            "QQ_AUTH_CODE",
            "FROM_NAME",
            "TEST_RECIPIENT",
            "SUBJECT",
        ],
    )

    contact = {
        "email": config["TEST_RECIPIENT"],
        "first_name": "Test",
        "company": "Test Company",
        "country": "Test Country",
        "segment": "business travel",
        "note": "test send",
    }
    body = render_template(load_template(), contact)
    message = build_message(
        from_email=config["QQ_EMAIL"],
        from_name=config["FROM_NAME"],
        to_email=config["TEST_RECIPIENT"],
        subject="[TEST] " + config["SUBJECT"],
        body=body,
    )

    send_message(config, message)
    print(f"Test email sent to {config['TEST_RECIPIENT']}")


if __name__ == "__main__":
    main()
