param(
    [Parameter(Mandatory = $true)]
    [string]$TargetDir
)

$ErrorActionPreference = "Stop"
$skillDir = Split-Path -Parent $PSScriptRoot
$assetsDir = Join-Path $skillDir "assets"
$target = [System.IO.Path]::GetFullPath($TargetDir)
$helperDir = Join-Path $target ".qq-email-outreach"

New-Item -ItemType Directory -Force -Path $target | Out-Null
New-Item -ItemType Directory -Force -Path $helperDir | Out-Null

$files = @(
    "mailer.py",
    "preview_campaign.py",
    "send_test.py",
    "send_campaign.py",
    "check_qq_connection.ps1",
    "run_test_email.ps1",
    "run_campaign.ps1",
    "email_template.txt",
    "contacts.csv",
    ".env.example"
)

foreach ($file in $files) {
    Copy-Item -Force (Join-Path $assetsDir $file) (Join-Path $target $file)
}

$envPath = Join-Path $target ".env"
if (-not (Test-Path $envPath)) {
    Copy-Item (Join-Path $assetsDir ".env.example") $envPath
}

$gitignorePath = Join-Path $target ".gitignore"
$gitignoreLines = @(".env", "sent_log.csv", "__pycache__/", "*.pyc")
$existing = if (Test-Path $gitignorePath) { Get-Content $gitignorePath } else { @() }
$merged = @($existing + $gitignoreLines | Select-Object -Unique)
Set-Content -Encoding UTF8 -Path $gitignorePath -Value $merged

Write-Host "QQ email outreach workspace initialized at $target"
Write-Host "Open .env locally and fill QQ_EMAIL, QQ_AUTH_CODE, TEST_RECIPIENT, FROM_NAME, and SUBJECT."
